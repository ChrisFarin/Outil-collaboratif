#!/bin/bash

if [ ! -f index.html ]
then
	exit 1
fi

line=$(cat index.html | grep "a href" | awk -F'"' '{print $2}')
for fic in $line
do
	echo -n "test -> $fic :"
	if [ -f $fic ]
	then
		echo " OK"
	else
		echo " NOK"
		exit 2
	fi
done

exit 0

